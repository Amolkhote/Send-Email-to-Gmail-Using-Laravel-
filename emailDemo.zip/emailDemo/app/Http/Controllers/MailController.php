<?php

namespace App\Http\Controllers;

use App\Mail\SendMail;
use Illuminate\Support\Facades\Mail;

class MailController extends Controller
{
    //
    public function send()
    {
        // mail::send(new SendMail());
        Mail::send(new SendMail());
    }
    public function email()
    {
        return view('email');
    }
}
