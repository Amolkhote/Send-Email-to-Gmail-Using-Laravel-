<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
    <h3>Hello Amol Message For You</h3>
    <h4>Email :- {{$email}}</h4>
    <h4>subject :- {{$subject}}</h4>
    <h4>Message :- {{$mess}}</h4>
    <h2>This Mail Send From Contact For</h2>
    <a align="center" href="www.innovationitsol.com"> Click Here For More Info</a>
    <a align="center" href="www.liteorient.tk/demo">Click Herre To Login</a>
    
</body>
</html>