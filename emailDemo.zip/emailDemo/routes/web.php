<?php

// use Symfony\Component\Routing\Route;

Route::get('/', function () {
    return view('welcome');
});

Route::post('/send', 'MailController@send');
Route::get('/email', 'MailController@email');