<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Contact Us</title>
</head>
<body>
    <h1>Send Mail Info</h1>
    <form action="send" method="POST">
        <?php echo csrf_field(); ?>
        your mail : <input type="text" name="your_mail"><br><br>
        Subject : <input type="text" name="subject"><br><br>
        message : <input type="text" name="message"> <br><br>
        <input type="submit" value="send">
    </form>
    
</body>
</html><?php /**PATH C:\xampp\htdocs\emailDemo\resources\views/email.blade.php ENDPATH**/ ?>